# Changelog - GS Location Changer

All notable changes to this project will be documented in this file.

## [1.0.2] - 2026-09-26

### Fixes
- **Stale Device Location Override**: Google caches a previously shared position in its `UULE` cookie and shows it as "From your device" (e.g. "10007, New York" while the selected country is Netherlands), overriding the `gl`/`uule` parameters. The extension now removes this cookie whenever it doesn't match the configured GPS coordinates, including before reloading the active search tab.
- **Chrome Web Store Update**: Added the `cookies` permission.

## [1.0.1] - 2026-09-25

### Improvements & Fixes
- **declarativeNetRequest Query Rewrite**: Rewrites search URL parameters directly before requests leave the browser, eliminating duplicate requests and resolving Google 403 automated traffic blocks.
- **Location & Country Sync**: Changing countries in the popup automatically updates canonical location, UULE, and GPS to prevent country-city parameter mismatches.
- **Chrome Web Store Update**: Updated manifest permissions with `declarativeNetRequestWithHostAccess`.

## [1.0.0] - 2026-09-07

### Initial Release & Enterprise Audit Hardening
- **Core Engine**: Full Google Search Location (`gl`), Language (`hl`), and Strict Restrict (`lr`) switching.
- **Protobuf UULE Generator**: Official Google-compliant Base64 Protobuf canonical UULE encoder and decoder supporting ASCII and international multi-byte UTF-8 locations (Urdu, Arabic, German, Spanish, Chinese, etc.).
- **Security Hardening**:
  - Eliminated DOM XSS vulnerabilities by migrating to safe DOM manipulation (`textContent` / `document.createElement`).
  - Added strict JSON schema validation for favorites imports with sanitization.
  - Strict Google domain validation preventing arbitrary host redirects.
- **Fail-Closed Privacy**: Geolocation emulation denies requests when coordinates are unassigned while spoofing is enabled, preventing real physical IP/GPS leakage.
- **Permissions & Lifecycle**:
  - Added `chrome.runtime.onStartup` for toolbar icon badge persistence across browser restarts.
  - Efficient storage change listener waking service worker only when badge state changes.
  - Native Google ccTLD routing for Quick Searches (e.g. `google.co.uk`, `google.com.pk`).
  - Consolidated state saving across all popup tabs.
  - Full keyboard accessibility (Arrow keys, Enter, Escape) on searchable dropdowns.
